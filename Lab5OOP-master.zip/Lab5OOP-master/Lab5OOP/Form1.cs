﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5OOP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private string RemoveSubstring(string input, int start, int len)
        {
            string result = "";

            // Проходимо по всім символам вхідного рядка.
            for (int i = 0; i < input.Length; i++)
            {
                // Якщо поточний індекс не належить інтервалу [start, start+len),
                // символ додається до результату.
                if (i < start || i >= start + len)
                {
                    result += input[i];
                }
            }
            return result;
        }


        private void btnRemove_Click(object sender, EventArgs e)
        {
            string input = txtInput.Text;
            int start, removeLength;

            // Пробуємо перетворити значення з текстових полів на числа.
            if (!int.TryParse(txtStart.Text, out start) || !int.TryParse(txtLength.Text, out removeLength))
            {
                MessageBox.Show("Введіть коректні числові значення для початкового індексу та довжини!");
                return;
            }

            // Перевіряємо, чи не виходять параметри за межі рядка.
            if (start < 0 || start + removeLength > input.Length)
            {
                MessageBox.Show("Значення індексу або довжини виходять за межі рядка!");
                return;
            }

            string result = RemoveSubstring(input, start, removeLength);
            txtResult.Text = result;
        }
    }

}
