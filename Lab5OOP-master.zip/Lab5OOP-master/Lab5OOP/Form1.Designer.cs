﻿using System.Windows.Forms;

namespace Lab5OOP
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private TextBox txtInput;
        private TextBox txtStart;
        private TextBox txtLength;
        private Button btnRemove;
        private TextBox txtResult;
        private Label lblInput;
        private Label lblStart;
        private Label lblLength;
        private Label lblResult;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
 
        private void InitializeComponent()
        {
            this.txtInput = new System.Windows.Forms.TextBox();
            this.txtStart = new System.Windows.Forms.TextBox();
            this.txtLength = new System.Windows.Forms.TextBox();
            this.btnRemove = new System.Windows.Forms.Button();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.lblInput = new System.Windows.Forms.Label();
            this.lblStart = new System.Windows.Forms.Label();
            this.lblLength = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtInput
            // 
            this.txtInput.Location = new System.Drawing.Point(112, 12);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(250, 20);
            this.txtInput.TabIndex = 1;
            // 
            // txtStart
            // 
            this.txtStart.Location = new System.Drawing.Point(138, 50);
            this.txtStart.Name = "txtStart";
            this.txtStart.Size = new System.Drawing.Size(60, 20);
            this.txtStart.TabIndex = 3;
            // 
            // txtLength
            // 
            this.txtLength.Location = new System.Drawing.Point(290, 47);
            this.txtLength.Name = "txtLength";
            this.txtLength.Size = new System.Drawing.Size(60, 20);
            this.txtLength.TabIndex = 5;
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(12, 80);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(150, 30);
            this.btnRemove.TabIndex = 6;
            this.btnRemove.Text = "Видалити підрядок";
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // txtResult
            // 
            this.txtResult.Location = new System.Drawing.Point(100, 117);
            this.txtResult.Name = "txtResult";
            this.txtResult.ReadOnly = true;
            this.txtResult.Size = new System.Drawing.Size(250, 20);
            this.txtResult.TabIndex = 8;
            // 
            // lblInput
            // 
            this.lblInput.Location = new System.Drawing.Point(12, 15);
            this.lblInput.Name = "lblInput";
            this.lblInput.Size = new System.Drawing.Size(94, 20);
            this.lblInput.TabIndex = 0;
            this.lblInput.Text = "Вхідний рядок:";
            // 
            // lblStart
            // 
            this.lblStart.Location = new System.Drawing.Point(12, 50);
            this.lblStart.Name = "lblStart";
            this.lblStart.Size = new System.Drawing.Size(105, 20);
            this.lblStart.TabIndex = 2;
            this.lblStart.Text = "Початковий індекс:";
            // 
            // lblLength
            // 
            this.lblLength.Location = new System.Drawing.Point(216, 50);
            this.lblLength.Name = "lblLength";
            this.lblLength.Size = new System.Drawing.Size(59, 20);
            this.lblLength.TabIndex = 4;
            this.lblLength.Text = "Довжина:";
            // 
            // lblResult
            // 
            this.lblResult.Location = new System.Drawing.Point(12, 120);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(80, 20);
            this.lblResult.TabIndex = 7;
            this.lblResult.Text = "Результат:";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(376, 169);
            this.Controls.Add(this.lblInput);
            this.Controls.Add(this.txtInput);
            this.Controls.Add(this.lblStart);
            this.Controls.Add(this.txtStart);
            this.Controls.Add(this.lblLength);
            this.Controls.Add(this.txtLength);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.txtResult);
            this.Name = "Form1";
            this.Text = "Лабораторна робота №5 - Варіант 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }

}

